// เวลาปัจจุบันของไทยในรูป 'YYYY-MM-DD HH:mm:ss' (เทียบกับค่าที่เก็บในตาราง time ได้ตรงๆ)
exports.nowBangkok = () =>
    new Date().toLocaleString('sv-SE', { timeZone: 'Asia/Bangkok' })
