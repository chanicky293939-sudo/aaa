exports.handleError = (res, err) => {
    if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ message: 'ข้อมูลซ้ำกับที่มีอยู่แล้ว' })
    }
    if (err.code === 'ER_ROW_IS_REFERENCED_2') {
        return res.status(409).json({ message: 'ข้อมูลนี้ถูกใช้งานอยู่ จึงลบไม่ได้' })
    }
    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
        return res.status(400).json({ message: 'อ้างอิงข้อมูลที่ไม่มีอยู่' })
    }
    console.error(err)
    return res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' })
}
