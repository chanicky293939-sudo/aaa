const multer = require('multer')
const path = require('path')
const fs = require('fs')

const dir = path.join(__dirname, '..', 'upload')
fs.mkdirSync(dir, { recursive: true })

const ALLOWED = ['.pdf', '.png', '.jpg', '.jpeg', '.webp', '.doc', '.docx', '.xls', '.xlsx']

module.exports = multer({
    storage: multer.diskStorage({
        destination: dir,
        filename: (req, file, cb) => {
            const ext = path.extname(file.originalname).toLowerCase()
            cb(null, `${Date.now()}-${Math.round(Math.random() * 1e6)}${ext}`)
        }
    }),
    limits: { fileSize: 5 * 1024 * 1024 },   // 5 MB
    fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase()
        if (!ALLOWED.includes(ext)) return cb(new Error('ชนิดไฟล์ไม่รองรับ'))
        cb(null, true)
    }
})
