const { pool } = require('../model/conn.js')
const { handleError } = require('./http.js')

// สร้าง handler list/create/update/remove ให้ตารางที่มีโครงสร้างง่ายๆ
module.exports = ({ table, pk, columns, required = [], orderBy }) => {
    const T = '`' + table + '`'
    const PK = '`' + pk + '`'
    const colList = columns.map(c => '`' + c + '`').join(', ')
    const clean = v => (v === '' || v === undefined ? null : v)
    const values = body => columns.map(c => clean(body[c]))
    const missing = body => required.filter(k => clean(body[k]) === null)

    return {
        list: async (req, res) => {
            try {
                const [rows] = await pool.query(`SELECT * FROM ${T} ORDER BY ${orderBy || PK}`)
                res.json(rows)
            } catch (err) { handleError(res, err) }
        },

        create: async (req, res) => {
            try {
                if (missing(req.body).length) {
                    return res.status(400).json({ message: 'กรอกข้อมูลให้ครบ' })
                }
                const [r] = await pool.query(
                    `INSERT INTO ${T} (${colList}) VALUES (${columns.map(() => '?').join(', ')})`,
                    values(req.body)
                )
                res.status(201).json({ message: 'เพิ่มข้อมูลสำเร็จ', id: r.insertId })
            } catch (err) { handleError(res, err) }
        },

        update: async (req, res) => {
            try {
                if (missing(req.body).length) {
                    return res.status(400).json({ message: 'กรอกข้อมูลให้ครบ' })
                }
                const [r] = await pool.query(
                    `UPDATE ${T} SET ${columns.map(c => '`' + c + '` = ?').join(', ')} WHERE ${PK} = ?`,
                    [...values(req.body), req.params.id]
                )
                if (!r.affectedRows) return res.status(404).json({ message: 'ไม่พบข้อมูล' })
                res.json({ message: 'แก้ไขข้อมูลสำเร็จ' })
            } catch (err) { handleError(res, err) }
        },

        remove: async (req, res) => {
            try {
                const [r] = await pool.query(`DELETE FROM ${T} WHERE ${PK} = ?`, [req.params.id])
                if (!r.affectedRows) return res.status(404).json({ message: 'ไม่พบข้อมูล' })
                res.json({ message: 'ลบข้อมูลสำเร็จ' })
            } catch (err) { handleError(res, err) }
        }
    }
}
