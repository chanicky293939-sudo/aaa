const { pool } = require('./conn.js')

// ดึงผู้ใช้พร้อมชื่อ role (ตาราง role: role_id, role)
exports.findByEmail = async (email) => {
  const [rows] = await pool.query(
    `SELECT u.*, r.role AS role_name
       FROM users u
       JOIN role r ON r.role_id = u.role
      WHERE u.email = ?`,
    [email]
  )
  return rows[0]
}

exports.create = async (u) => {
  const [result] = await pool.query(
    `INSERT INTO users
      (username, email, password, salary, phone, czid, department, \`level\`, \`position\`, \`role\`)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [u.username, u.email, u.password, u.salary, u.phone, u.czid,
     u.department, u.level, u.position, u.role]
  )
  return result.insertId
}
