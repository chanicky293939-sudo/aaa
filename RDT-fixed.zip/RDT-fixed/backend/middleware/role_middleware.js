const { pool } = require('../model/conn.js')

// ตรวจบทบาทจากฐานข้อมูลทุกครั้ง (เปลี่ยน role แล้วมีผลทันที ไม่ต้องรอ token หมดอายุ)
exports.requireAdmin = async (req, res, next) => {
    try {
        const [rows] = await pool.query(
            `SELECT r.role FROM users u JOIN role r ON r.role_id = u.role WHERE u.id = ?`,
            [req.user.id]
        )
        if (!rows[0] || rows[0].role !== 'admin') {
            return res.status(403).json({ message: 'เฉพาะผู้ดูแลระบบ' })
        }
        next()
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' })
    }
}

// กรรมการ = ผู้ใช้ที่มีแถวในตาราง boardsign
exports.requireBoard = async (req, res, next) => {
    try {
        const [rows] = await pool.query(
            `SELECT bs.sign_id, br.role
               FROM boardsign bs JOIN boardrole br ON br.role_id = bs.role
              WHERE bs.id = ? LIMIT 1`,
            [req.user.id]
        )
        if (!rows[0]) return res.status(403).json({ message: 'เฉพาะคณะกรรมการประเมิน' })
        req.board = rows[0]
        next()
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' })
    }
}
