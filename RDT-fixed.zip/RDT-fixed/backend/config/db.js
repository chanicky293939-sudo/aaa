const mysql = require('mysql2/promise')

const db = mysql.createPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
    waitForConnections: true,
    connectionLimit: 10,
    dateStrings: true,      // DATETIME ส่งออกเป็นข้อความ 'YYYY-MM-DD HH:mm:ss' ไม่เลื่อนเขตเวลา
    decimalNumbers: true    // DECIMAL ส่งออกเป็นตัวเลข
});

module.exports = { db };
