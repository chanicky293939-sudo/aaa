const express = require('express')
const router = express.Router()

const auth = require('../middleware/auth_middleware.js')
const { requireAdmin } = require('../middleware/role_middleware.js')
const crud = require('../utils/crud.js')
const { indicatorList, currentRound } = require('../controller/eval_controller.js')

// path, ตาราง, PK, คอลัมน์ที่แก้ไขได้, public = อ่านได้โดยไม่ต้อง login (ใช้ในหน้าสมัครสมาชิก)
const TABLES = [
    { path: 'department', table: 'department', pk: 'department_id', columns: ['department'], required: ['department'], public: true },
    { path: 'level',      table: 'level',      pk: 'level_id',      columns: ['level'],      required: ['level'],      public: true },
    { path: 'position',   table: 'position',   pk: 'position_id',   columns: ['position'],   required: ['position'],   public: true },
    { path: 'role',       table: 'role',       pk: 'role_id',       columns: ['role'],       required: ['role'] },
    { path: 'boardrole',  table: 'boardrole',  pk: 'role_id',       columns: ['role'],       required: ['role'] },
    { path: 'section',    table: 'section',    pk: 'section_id',    columns: ['section', 'weight'], required: ['section'] },
    { path: 'time',       table: 'time',       pk: 'time_id',       columns: ['start', 'expire'],   required: ['start', 'expire'], orderBy: '`start` DESC' },
    { path: 'indicator',  table: 'indicator',  pk: 'indicator_id',
      columns: ['indicator', 'section_id', 'detail', 'type', 'freq'], required: ['indicator', 'section_id'] }
]

// ต้องวางก่อนเส้นทางที่มี :id
router.get('/time/current', auth, currentRound)

for (const cfg of TABLES) {
    const c = crud(cfg)
    const list = cfg.path === 'indicator' ? indicatorList : c.list   // ตัวชี้วัดต้อง join หมวด
    const read = cfg.public ? [] : [auth]

    router.get(`/${cfg.path}`, ...read, list)
    router.post(`/${cfg.path}`, auth, requireAdmin, c.create)
    router.put(`/${cfg.path}/:id`, auth, requireAdmin, c.update)
    router.delete(`/${cfg.path}/:id`, auth, requireAdmin, c.remove)
}

module.exports = router
