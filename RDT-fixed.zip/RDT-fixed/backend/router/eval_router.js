const express = require('express')
const router = express.Router()

const auth = require('../middleware/auth_middleware.js')
const { requireAdmin, requireBoard } = require('../middleware/role_middleware.js')
const upload = require('../utils/upload.js')
const ctrl = require('../controller/eval_controller.js')
const admin = require('../controller/admin_controller.js')
const { MAX_SCORE } = require('../config/eval.js')

router.get('/eval/config', auth, (req, res) => res.json({ maxScore: MAX_SCORE }))

// ประเมินตนเอง
router.get('/userresult/me', auth, ctrl.myResults)
router.post('/userresult', auth, upload.single('file'), ctrl.saveMyResult)

// กรรมการ
router.get('/board/me', auth, ctrl.boardMe)
router.get('/board/targets', auth, requireBoard, ctrl.boardTargets)
router.get('/board/evaluation', auth, requireBoard, ctrl.boardGet)
router.post('/board/evaluation', auth, requireBoard, upload.single('signature'), ctrl.boardSave)

// สรุปผล
router.get('/report/me', auth, ctrl.reportMe)
router.get('/report/summary', auth, requireAdmin, ctrl.reportSummary)

// ผู้ดูแลระบบ: ผู้ใช้ และการแต่งตั้งกรรมการ
router.get('/users', auth, requireAdmin, admin.userList)
router.put('/users/:id/role', auth, requireAdmin, admin.userSetRole)
router.delete('/users/:id', auth, requireAdmin, admin.userRemove)

router.get('/boardsign', auth, requireAdmin, admin.boardList)
router.post('/boardsign', auth, requireAdmin, admin.boardAdd)
router.delete('/boardsign/:id', auth, requireAdmin, admin.boardRemove)

module.exports = router
