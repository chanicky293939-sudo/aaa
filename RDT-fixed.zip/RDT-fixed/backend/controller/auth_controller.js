const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const authModel = require('../model/auth_model.js')

const DEFAULT_ROLE_ID = 2   // role_id ของ 'user' ในตาราง role (ดู schema.sql)

exports.register = async (req, res) => {
    try {
        const { username, email, password, salary, phone, czid, department, level, position } = req.body

        if (!username || !email || !password || !phone || !czid || !department || !level || !position) {
            return res.status(400).json({ message: 'กรอกข้อมูลให้ครบ' })
        }

        const mail = email.trim().toLowerCase()

        if (await authModel.findByEmail(mail)) {
            return res.status(409).json({ message: 'อีเมลนี้ถูกใช้แล้ว' })
        }

        const hash = await bcrypt.hash(password, 10)

        const id = await authModel.create({
            username: username.trim(),
            email: mail,
            password: hash,
            salary: salary || 0,
            phone, czid, department, level, position,
            role: DEFAULT_ROLE_ID    // กำหนดฝั่ง server ไม่รับจากหน้าเว็บ
        })

        return res.status(201).json({ message: 'สมัครสมาชิกสำเร็จ', id })
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ message: 'อีเมลหรือเลขบัตรประชาชนนี้ถูกใช้แล้ว' })
        }
        if (err.code === 'ER_NO_REFERENCED_ROW_2') {
            return res.status(400).json({ message: 'รหัสแผนก/ระดับ/ตำแหน่งไม่ถูกต้อง' })
        }
        console.error(err)
        return res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' })
    }
}

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body

        if (!email || !password) {
            return res.status(400).json({ message: 'กรุณากรอกอีเมลและรหัสผ่าน' })
        }

        const user = await authModel.findByEmail(email.trim().toLowerCase())

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' })
        }

        // middleware อ่าน decoded.sub เป็น id ของผู้ใช้
        const token = jwt.sign(
            { sub: user.id, role: user.role_name },
            process.env.JWT_SECRET,
            { expiresIn: '1d' }
        )

        return res.json({
            message: 'เข้าสู่ระบบสำเร็จ',
            token,
            user: { id: user.id, username: user.username, email: user.email, role: user.role_name }
        })
    } catch (err) {
        console.error(err)
        return res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' })
    }
}
