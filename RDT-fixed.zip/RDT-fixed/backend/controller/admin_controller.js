const { pool } = require('../model/conn.js')
const { handleError } = require('../utils/http.js')

exports.userList = async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT u.id, u.username, u.email, u.phone, u.czid, u.salary,
                    u.department, u.\`level\`, u.\`position\`, u.\`role\`,
                    d.department AS department_name, l.\`level\` AS level_name,
                    p.\`position\` AS position_name, r.\`role\` AS role_name
               FROM users u
               JOIN department d ON d.department_id = u.department
               JOIN \`level\` l ON l.level_id = u.\`level\`
               JOIN \`position\` p ON p.position_id = u.\`position\`
               JOIN \`role\` r ON r.role_id = u.\`role\`
              ORDER BY u.id`
        )
        res.json(rows)
    } catch (err) { handleError(res, err) }
}

exports.userSetRole = async (req, res) => {
    try {
        const { role } = req.body
        if (!role) return res.status(400).json({ message: 'ระบุบทบาท' })
        // กันผู้ดูแลคนสุดท้ายถูกถอดสิทธิ์ตัวเอง
        if (Number(req.params.id) === req.user.id) {
            return res.status(400).json({ message: 'เปลี่ยนบทบาทของตัวเองไม่ได้' })
        }
        const [r] = await pool.query('UPDATE users SET `role` = ? WHERE id = ?', [role, req.params.id])
        if (!r.affectedRows) return res.status(404).json({ message: 'ไม่พบผู้ใช้' })
        res.json({ message: 'เปลี่ยนบทบาทสำเร็จ' })
    } catch (err) { handleError(res, err) }
}

exports.userRemove = async (req, res) => {
    try {
        if (Number(req.params.id) === req.user.id) {
            return res.status(400).json({ message: 'ลบบัญชีของตัวเองไม่ได้' })
        }
        const [r] = await pool.query('DELETE FROM users WHERE id = ?', [req.params.id])
        if (!r.affectedRows) return res.status(404).json({ message: 'ไม่พบผู้ใช้' })
        res.json({ message: 'ลบผู้ใช้สำเร็จ' })
    } catch (err) { handleError(res, err) }
}

// ---------- คณะกรรมการ ----------
exports.boardList = async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT bs.sign_id, bs.id, bs.\`role\`, u.username, br.\`role\` AS role_name
               FROM boardsign bs
               JOIN users u ON u.id = bs.id
               JOIN boardrole br ON br.role_id = bs.\`role\`
              ORDER BY bs.sign_id`
        )
        res.json(rows)
    } catch (err) { handleError(res, err) }
}

exports.boardAdd = async (req, res) => {
    try {
        const { id, role } = req.body
        if (!id || !role) return res.status(400).json({ message: 'กรอกข้อมูลให้ครบ' })
        const [exists] = await pool.query('SELECT sign_id FROM boardsign WHERE id = ?', [id])
        if (exists[0]) return res.status(409).json({ message: 'ผู้ใช้นี้เป็นกรรมการอยู่แล้ว' })
        const [r] = await pool.query('INSERT INTO boardsign (id, `role`) VALUES (?, ?)', [id, role])
        res.status(201).json({ message: 'เพิ่มกรรมการสำเร็จ', id: r.insertId })
    } catch (err) { handleError(res, err) }
}

exports.boardRemove = async (req, res) => {
    try {
        const [r] = await pool.query('DELETE FROM boardsign WHERE sign_id = ?', [req.params.id])
        if (!r.affectedRows) return res.status(404).json({ message: 'ไม่พบข้อมูล' })
        res.json({ message: 'ลบกรรมการสำเร็จ' })
    } catch (err) { handleError(res, err) }
}
