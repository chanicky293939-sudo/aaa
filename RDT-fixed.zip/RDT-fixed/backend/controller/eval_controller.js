const { pool, withtx } = require('../model/conn.js')
const { handleError } = require('../utils/http.js')
const { nowBangkok } = require('../utils/time.js')
const { MAX_SCORE } = require('../config/eval.js')

const getRound = async (time_id) => {
    const [rows] = await pool.query('SELECT * FROM `time` WHERE time_id = ?', [time_id])
    return rows[0]
}
const isOpen = (round) => {
    const now = nowBangkok()
    return !!round && round.start <= now && now <= round.expire
}
const validScore = (s) => {
    const n = Number(s)
    return s !== '' && s !== null && Number.isFinite(n) && n >= 0 && n <= MAX_SCORE
}

// ---------- รอบเวลา ----------
exports.currentRound = async (req, res) => {
    try {
        const [rows] = await pool.query(
            'SELECT * FROM `time` WHERE `start` <= ? AND expire >= ? ORDER BY `start` DESC LIMIT 1',
            [nowBangkok(), nowBangkok()]
        )
        res.json(rows[0] || null)
    } catch (err) { handleError(res, err) }
}

// ---------- ตัวชี้วัดพร้อมหมวด ----------
exports.indicatorList = async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT i.*, s.\`section\`, s.weight
               FROM indicator i JOIN section s ON s.section_id = i.section_id
              ORDER BY s.section_id, i.indicator_id`
        )
        res.json(rows)
    } catch (err) { handleError(res, err) }
}

// ---------- ประเมินตนเอง ----------
exports.myResults = async (req, res) => {
    try {
        const [rows] = await pool.query(
            'SELECT * FROM userresult WHERE id = ? AND time_id = ?',
            [req.user.id, req.query.time_id]
        )
        res.json(rows)
    } catch (err) { handleError(res, err) }
}

exports.saveMyResult = async (req, res) => {
    try {
        const { indicator_id, time_id, score } = req.body
        if (!indicator_id || !time_id || !validScore(score)) {
            return res.status(400).json({ message: `คะแนนต้องเป็นตัวเลข 0 - ${MAX_SCORE}` })
        }
        const round = await getRound(time_id)
        if (!round) return res.status(404).json({ message: 'ไม่พบรอบการประเมิน' })
        if (!isOpen(round)) return res.status(403).json({ message: 'ไม่อยู่ในช่วงเวลาประเมิน' })

        const file = req.file ? '/upload/' + req.file.filename : null
        await pool.query(
            `INSERT INTO userresult (id, indicator_id, time_id, score, \`file\`)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE score = VALUES(score), \`file\` = COALESCE(VALUES(\`file\`), \`file\`)`,
            [req.user.id, indicator_id, time_id, Number(score), file]
        )
        res.json({ message: 'บันทึกสำเร็จ' })
    } catch (err) { handleError(res, err) }
}

// ---------- กรรมการ ----------
exports.boardMe = async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT br.role FROM boardsign bs JOIN boardrole br ON br.role_id = bs.role
              WHERE bs.id = ? LIMIT 1`,
            [req.user.id]
        )
        res.json({ isBoard: !!rows[0], role: rows[0]?.role || null })
    } catch (err) { handleError(res, err) }
}

exports.boardTargets = async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT u.id, u.username, d.department, p.\`position\`
               FROM users u
               JOIN department d ON d.department_id = u.department
               JOIN \`position\` p ON p.position_id = u.\`position\`
              WHERE u.id <> ?
              ORDER BY u.username`,
            [req.user.id]
        )
        res.json(rows)
    } catch (err) { handleError(res, err) }
}

exports.boardGet = async (req, res) => {
    try {
        const { target, time_id } = req.query
        const [self] = await pool.query(
            'SELECT indicator_id, score, `file` FROM userresult WHERE id = ? AND time_id = ?',
            [target, time_id])
        const [board] = await pool.query(
            'SELECT indicator_id, score FROM boardresult WHERE id = ? AND board_id = ? AND time_id = ?',
            [target, req.user.id, time_id])
        const [att] = await pool.query(
            'SELECT indicator_id, comment, signature FROM boardattachment WHERE id = ? AND board_id = ? AND time_id = ?',
            [target, req.user.id, time_id])
        res.json({ self, board, attachments: att })
    } catch (err) { handleError(res, err) }
}

exports.boardSave = async (req, res) => {
    try {
        const { target, time_id } = req.body
        let items
        try { items = JSON.parse(req.body.items || '[]') } catch { items = null }

        if (!target || !time_id || !Array.isArray(items) || !items.length) {
            return res.status(400).json({ message: 'ข้อมูลไม่ครบ' })
        }
        if (Number(target) === req.user.id) {
            return res.status(400).json({ message: 'ประเมินตนเองในฐานะกรรมการไม่ได้' })
        }
        if (items.some(i => !i.indicator_id || !validScore(i.score))) {
            return res.status(400).json({ message: `คะแนนต้องเป็นตัวเลข 0 - ${MAX_SCORE}` })
        }
        const round = await getRound(time_id)
        if (!round) return res.status(404).json({ message: 'ไม่พบรอบการประเมิน' })
        if (!isOpen(round)) return res.status(403).json({ message: 'ไม่อยู่ในช่วงเวลาประเมิน' })

        const signature = req.file ? '/upload/' + req.file.filename : null

        await withtx(async (conn) => {
            for (const it of items) {
                await conn.query(
                    `INSERT INTO boardresult (id, board_id, indicator_id, time_id, score)
                     VALUES (?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE score = VALUES(score)`,
                    [target, req.user.id, it.indicator_id, time_id, Number(it.score)]
                )
                await conn.query(
                    `INSERT INTO boardattachment (id, board_id, indicator_id, time_id, comment, signature)
                     VALUES (?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE comment = VALUES(comment),
                                             signature = COALESCE(VALUES(signature), signature)`,
                    [target, req.user.id, it.indicator_id, time_id, it.comment || null, signature]
                )
            }
        })
        res.json({ message: 'บันทึกผลการประเมินสำเร็จ' })
    } catch (err) { handleError(res, err) }
}

// ---------- สรุปผล ----------
const summarySql = (withUser) => `
    SELECT u.id, u.username, d.department, s.self_total, b.board_avg, b.board_count
      FROM users u
      JOIN department d ON d.department_id = u.department
      LEFT JOIN (SELECT id, SUM(score) AS self_total
                   FROM userresult WHERE time_id = ? GROUP BY id) s ON s.id = u.id
      LEFT JOIN (SELECT id, AVG(t) AS board_avg, COUNT(*) AS board_count
                   FROM (SELECT id, board_id, SUM(score) AS t
                           FROM boardresult WHERE time_id = ? GROUP BY id, board_id) x
                  GROUP BY id) b ON b.id = u.id
     ${withUser ? 'WHERE u.id = ?' : ''}
     ORDER BY u.id`

exports.reportSummary = async (req, res) => {
    try {
        const [rows] = await pool.query(summarySql(false), [req.query.time_id, req.query.time_id])
        res.json(rows)
    } catch (err) { handleError(res, err) }
}

exports.reportMe = async (req, res) => {
    try {
        const [rows] = await pool.query(summarySql(true),
            [req.query.time_id, req.query.time_id, req.user.id])
        res.json(rows[0] || null)
    } catch (err) { handleError(res, err) }
}
