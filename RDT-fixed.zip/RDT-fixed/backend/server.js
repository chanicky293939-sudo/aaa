require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');

const app = express();

if (!process.env.JWT_SECRET) {
  throw new Error('กรุณากำหนด JWT_SECRET ใน .env');
}

app.use(cors());
app.use(express.json());
app.use('/upload', express.static(path.join(__dirname, 'upload')));

const authRoute = require('./router/auth_router');
const masterRoute = require('./router/master_router');
const evalRoute = require('./router/eval_router');
const authMiddleware = require('./middleware/auth_middleware');

app.use('/api/auth', authRoute);
app.use('/api', masterRoute);
app.use('/api', evalRoute);

// ตัวอย่าง API ที่ต้องมี JWT
app.get('/api/auth/me', authMiddleware, (req, res) => {
  res.json({
    message: 'Token ถูกต้อง',
    userId: req.user.id
  });
});

// error จาก multer (ไฟล์ใหญ่เกิน / ชนิดไม่รองรับ) และ error อื่นที่หลุดมา
app.use((err, req, res, next) => {
  if (err.name === 'MulterError' || err.message === 'ชนิดไฟล์ไม่รองรับ') {
    const msg = err.code === 'LIMIT_FILE_SIZE' ? 'ไฟล์ใหญ่เกิน 5 MB' : err.message;
    return res.status(400).json({ message: msg });
  }
  console.error(err);
  res.status(500).json({ message: 'เกิดข้อผิดพลาดของเซิร์ฟเวอร์' });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
