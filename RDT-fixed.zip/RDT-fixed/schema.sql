-- ระบบประเมินบุคลากรด้วยระบบเทคโนโลยีสารสนเทศสมัยใหม่
-- วิทยาลัยเทคนิคพังงา : schema ตาม ER diagram (MariaDB / MySQL)
-- วิธีใช้: phpMyAdmin > เลือก database my_database > แท็บ Import > เลือกไฟล์นี้

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS my_database
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE my_database;

-- ------------------------------------------------------------
-- (ไม่บังคับ) ล้างตารางเก่าทั้งหมดก่อนสร้างใหม่ ข้อมูลจะหาย!
-- ถ้าต้องการ ให้ลบ -- หน้าบรรทัดข้างล่างนี้ออก
-- ------------------------------------------------------------
-- SET FOREIGN_KEY_CHECKS = 0;
-- DROP TABLE IF EXISTS boardattachment, boardresult, userresult, boardsign, usersign,
--   `time`, indicator, section, boardrole, users, `role`, `position`, `level`, department;
-- SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- ตารางข้อมูลอ้างอิง (lookup)
-- ============================================================

CREATE TABLE IF NOT EXISTS department (
  department_id INT AUTO_INCREMENT PRIMARY KEY,
  department    VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `level` (
  level_id INT AUTO_INCREMENT PRIMARY KEY,
  `level`  VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `position` (
  position_id INT AUTO_INCREMENT PRIMARY KEY,
  `position`  VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `role` (
  role_id INT AUTO_INCREMENT PRIMARY KEY,
  `role`  VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

-- ============================================================
-- ผู้ใช้
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  username   VARCHAR(100) NOT NULL,
  email      VARCHAR(100) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,                 -- เก็บค่า hash จาก bcrypt
  salary     DECIMAL(12,2) NOT NULL DEFAULT 0,
  phone      VARCHAR(20)  NOT NULL,                 -- varchar เพื่อเก็บเลข 0 นำหน้า
  czid       CHAR(13)     NOT NULL UNIQUE,          -- เลขบัตรประชาชน 13 หลัก
  department INT NOT NULL,
  `level`    INT NOT NULL,
  `position` INT NOT NULL,
  `role`     INT NOT NULL,
  CONSTRAINT fk_users_department FOREIGN KEY (department) REFERENCES department(department_id),
  CONSTRAINT fk_users_level      FOREIGN KEY (`level`)    REFERENCES `level`(level_id),
  CONSTRAINT fk_users_position   FOREIGN KEY (`position`) REFERENCES `position`(position_id),
  CONSTRAINT fk_users_role       FOREIGN KEY (`role`)     REFERENCES `role`(role_id)
) ENGINE=InnoDB;

-- ลายเซ็นผู้ใช้ (ตาม ER มีแค่ sign_id กับ id)
CREATE TABLE IF NOT EXISTS usersign (
  sign_id INT AUTO_INCREMENT PRIMARY KEY,
  id      INT NOT NULL,
  CONSTRAINT fk_usersign_user FOREIGN KEY (id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- คณะกรรมการ
-- ============================================================

CREATE TABLE IF NOT EXISTS boardrole (
  role_id INT AUTO_INCREMENT PRIMARY KEY,
  `role`  VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS boardsign (
  sign_id INT AUTO_INCREMENT PRIMARY KEY,
  id      INT NOT NULL,
  `role`  INT NOT NULL,
  CONSTRAINT fk_boardsign_user FOREIGN KEY (id)     REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_boardsign_role FOREIGN KEY (`role`) REFERENCES boardrole(role_id)
) ENGINE=InnoDB;

-- ============================================================
-- หมวด / ตัวชี้วัด / รอบเวลาประเมิน
-- ============================================================

CREATE TABLE IF NOT EXISTS section (
  section_id INT AUTO_INCREMENT PRIMARY KEY,
  `section`  VARCHAR(255) NOT NULL,
  weight     DECIMAL(5,2) NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS indicator (
  indicator_id INT AUTO_INCREMENT PRIMARY KEY,
  indicator    VARCHAR(255) NOT NULL,
  section_id   INT NOT NULL,
  detail       TEXT NULL,
  `type`       VARCHAR(50) NULL,
  freq         VARCHAR(50) NULL,
  CONSTRAINT fk_indicator_section FOREIGN KEY (section_id) REFERENCES section(section_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `time` (
  time_id INT AUTO_INCREMENT PRIMARY KEY,
  `start` DATETIME NOT NULL,
  expire  DATETIME NOT NULL
) ENGINE=InnoDB;

-- ============================================================
-- ผลการประเมิน
-- ============================================================

-- ผลที่ผู้ใช้ประเมินตนเอง
CREATE TABLE IF NOT EXISTS userresult (
  result_id    INT AUTO_INCREMENT PRIMARY KEY,
  id           INT NOT NULL,
  indicator_id INT NOT NULL,
  time_id      INT NOT NULL,
  score        DECIMAL(5,2) NOT NULL DEFAULT 0,
  `file`       VARCHAR(255) NULL,                   -- path ไฟล์แนบ
  CONSTRAINT fk_ur_user      FOREIGN KEY (id)           REFERENCES users(id),
  CONSTRAINT fk_ur_indicator FOREIGN KEY (indicator_id) REFERENCES indicator(indicator_id),
  CONSTRAINT fk_ur_time      FOREIGN KEY (time_id)      REFERENCES `time`(time_id),
  UNIQUE KEY uq_userresult (id, indicator_id, time_id)
) ENGINE=InnoDB;

-- ผลที่กรรมการให้คะแนน (id = ผู้ถูกประเมิน, board_id = กรรมการ)
CREATE TABLE IF NOT EXISTS boardresult (
  result_id    INT AUTO_INCREMENT PRIMARY KEY,
  id           INT NOT NULL,
  board_id     INT NOT NULL,
  indicator_id INT NOT NULL,
  time_id      INT NOT NULL,
  score        DECIMAL(5,2) NOT NULL DEFAULT 0,
  `file`       VARCHAR(255) NULL,
  CONSTRAINT fk_br_user      FOREIGN KEY (id)           REFERENCES users(id),
  CONSTRAINT fk_br_board     FOREIGN KEY (board_id)     REFERENCES users(id),
  CONSTRAINT fk_br_indicator FOREIGN KEY (indicator_id) REFERENCES indicator(indicator_id),
  CONSTRAINT fk_br_time      FOREIGN KEY (time_id)      REFERENCES `time`(time_id),
  UNIQUE KEY uq_boardresult (id, board_id, indicator_id, time_id)
) ENGINE=InnoDB;

-- ความเห็นและลายเซ็นของกรรมการ
CREATE TABLE IF NOT EXISTS boardattachment (
  result_id    INT AUTO_INCREMENT PRIMARY KEY,
  id           INT NOT NULL,
  board_id     INT NOT NULL,
  indicator_id INT NOT NULL,
  time_id      INT NOT NULL,
  comment      TEXT NULL,
  signature    VARCHAR(255) NULL,                   -- path รูปลายเซ็น
  CONSTRAINT fk_ba_user      FOREIGN KEY (id)           REFERENCES users(id),
  CONSTRAINT fk_ba_board     FOREIGN KEY (board_id)     REFERENCES users(id),
  CONSTRAINT fk_ba_indicator FOREIGN KEY (indicator_id) REFERENCES indicator(indicator_id),
  CONSTRAINT fk_ba_time      FOREIGN KEY (time_id)      REFERENCES `time`(time_id),
  UNIQUE KEY uq_boardattachment (id, board_id, indicator_id, time_id)
) ENGINE=InnoDB;

-- ============================================================
-- ข้อมูลตั้งต้น (แก้ชื่อให้ตรงกับของจริงได้)
-- ============================================================

INSERT IGNORE INTO `role` (role_id, `role`) VALUES
  (1, 'admin'),
  (2, 'user');          -- ผู้ใช้ทั่วไป: ระบบสมัครสมาชิกใช้ role_id = 2 เป็นค่าเริ่มต้น

INSERT IGNORE INTO department (department_id, department) VALUES
  (1, 'แผนกวิชาช่างยนต์'),
  (2, 'แผนกวิชาช่างไฟฟ้ากำลัง'),
  (3, 'แผนกวิชาอิเล็กทรอนิกส์'),
  (4, 'แผนกวิชาเทคโนโลยีสารสนเทศ'),
  (5, 'แผนกวิชาการบัญชี');

INSERT IGNORE INTO `level` (level_id, `level`) VALUES
  (1, 'ครูผู้ช่วย'),
  (2, 'ครู คศ.1'),
  (3, 'ครู คศ.2'),
  (4, 'ครู คศ.3'),
  (5, 'ครู คศ.4');

INSERT IGNORE INTO `position` (position_id, `position`) VALUES
  (1, 'ครู'),
  (2, 'หัวหน้าแผนก'),
  (3, 'รองผู้อำนวยการ'),
  (4, 'ผู้อำนวยการ');

INSERT IGNORE INTO boardrole (role_id, `role`) VALUES
  (1, 'ประธานกรรมการ'),
  (2, 'กรรมการ'),
  (3, 'เลขานุการ');
