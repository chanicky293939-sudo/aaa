// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  devtools: { enabled: true },
  ssr: false,                                  // ระบบภายใน ใช้แบบ SPA (ไม่มีปัญหา hydration)
  css: ['~/assets/main.css'],
  runtimeConfig: {
    public: { apiBase: 'http://localhost:5000' }   // พอร์ตของ backend (.env PORT)
  }
})
