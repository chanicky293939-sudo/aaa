<script setup>
const api = useApi()
const me = useCookie('user')
const users = ref([])
const roles = ref([])
const msg = ref('')
const err = ref('')

async function load() {
  ;[users.value, roles.value] = await Promise.all([api('/users'), api('/role')])
}
onMounted(load)

async function setRole(u, role) {
  msg.value = ''; err.value = ''
  try {
    msg.value = (await api(`/users/${u.id}/role`, { method: 'PUT', body: { role } })).message
  } catch (e) { err.value = errMsg(e) }
  await load()
}

async function remove(u) {
  if (!confirm(`ลบผู้ใช้ ${u.username}?`)) return
  msg.value = ''; err.value = ''
  try {
    msg.value = (await api(`/users/${u.id}`, { method: 'DELETE' })).message
  } catch (e) { err.value = errMsg(e) }
  await load()
}
</script>

<template>
  <div>
    <h1>ผู้ใช้</h1>
    <div v-if="msg" class="msg ok">{{ msg }}</div>
    <div v-if="err" class="msg err">{{ err }}</div>
    <div class="card table-wrap">
      <table>
        <thead><tr><th>#</th><th>ชื่อ</th><th>อีเมล</th><th>แผนก</th><th>ระดับ</th><th>ตำแหน่ง</th><th>บทบาท</th><th></th></tr></thead>
        <tbody>
          <tr v-for="u in users" :key="u.id">
            <td>{{ u.id }}</td>
            <td>{{ u.username }}</td>
            <td>{{ u.email }}</td>
            <td>{{ u.department_name }}</td>
            <td>{{ u.level_name }}</td>
            <td>{{ u.position_name }}</td>
            <td>
              <select :value="u.role" :disabled="u.id === me?.id" @change="setRole(u, $event.target.value)">
                <option v-for="r in roles" :key="r.role_id" :value="r.role_id">{{ r.role }}</option>
              </select>
            </td>
            <td><button class="small red" :disabled="u.id === me?.id" @click="remove(u)">ลบ</button></td>
          </tr>
        </tbody>
      </table>
    </div>
    <p class="muted">เมื่อเปลี่ยนบทบาท จะมีผลกับการเข้าถึงหน้าผู้ดูแลทันทีที่ผู้ใช้เข้าสู่ระบบใหม่</p>
  </div>
</template>
