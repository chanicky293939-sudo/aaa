<script setup>
const api = useApi()
const members = ref([])
const users = ref([])
const boardroles = ref([])
const form = reactive({ id: '', role: '' })
const msg = ref('')
const err = ref('')

async function load() {
  ;[members.value, users.value, boardroles.value] =
    await Promise.all([api('/boardsign'), api('/users'), api('/boardrole')])
}
onMounted(load)

const candidates = computed(() => {
  const taken = new Set(members.value.map(m => m.id))
  return users.value.filter(u => !taken.has(u.id))
})

async function add() {
  msg.value = ''; err.value = ''
  try {
    msg.value = (await api('/boardsign', { method: 'POST', body: { ...form } })).message
    form.id = ''; form.role = ''
    await load()
  } catch (e) { err.value = errMsg(e) }
}

async function remove(m) {
  if (!confirm(`ถอด ${m.username} ออกจากกรรมการ?`)) return
  msg.value = ''; err.value = ''
  try {
    msg.value = (await api(`/boardsign/${m.sign_id}`, { method: 'DELETE' })).message
    await load()
  } catch (e) { err.value = errMsg(e) }
}
</script>

<template>
  <div>
    <h1>คณะกรรมการประเมิน</h1>
    <div v-if="msg" class="msg ok">{{ msg }}</div>
    <div v-if="err" class="msg err">{{ err }}</div>
    <div v-if="!boardroles.length" class="msg info">
      ต้องเพิ่ม <NuxtLink to="/admin/boardrole">ตำแหน่งกรรมการ</NuxtLink> ก่อน
    </div>

    <form class="card" @submit.prevent="add">
      <div class="row">
        <select v-model="form.id" required>
          <option value="" disabled>เลือกผู้ใช้</option>
          <option v-for="u in candidates" :key="u.id" :value="u.id">{{ u.username }} ({{ u.email }})</option>
        </select>
        <select v-model="form.role" required>
          <option value="" disabled>เลือกตำแหน่งกรรมการ</option>
          <option v-for="r in boardroles" :key="r.role_id" :value="r.role_id">{{ r.role }}</option>
        </select>
        <button class="green">แต่งตั้งเป็นกรรมการ</button>
      </div>
    </form>

    <div class="card table-wrap">
      <table>
        <thead><tr><th>#</th><th>ชื่อ</th><th>ตำแหน่งกรรมการ</th><th></th></tr></thead>
        <tbody>
          <tr v-for="m in members" :key="m.sign_id">
            <td>{{ m.sign_id }}</td><td>{{ m.username }}</td><td>{{ m.role_name }}</td>
            <td><button class="small red" @click="remove(m)">ถอดออก</button></td>
          </tr>
          <tr v-if="!members.length"><td colspan="4" class="muted">ยังไม่มีกรรมการ</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
