<template>
  <div>
    <h1>จัดการข้อมูลพื้นฐาน</h1>
    <div class="grid">
      <NuxtLink class="tile" to="/admin/users"><b>ผู้ใช้</b><span>ดูรายชื่อ เปลี่ยนบทบาท ลบผู้ใช้</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/board"><b>คณะกรรมการ</b><span>แต่งตั้งผู้ใช้เป็นกรรมการประเมิน</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/time"><b>รอบเวลาประเมิน</b><span>กำหนดช่วงเริ่ม-สิ้นสุดของแต่ละรอบ</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/section"><b>หมวดการประเมิน</b><span>หมวดและน้ำหนัก</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/indicator"><b>ตัวชี้วัด</b><span>ตัวชี้วัดในแต่ละหมวด</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/department"><b>แผนก</b><span>เพิ่ม แก้ไข ลบ</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/level"><b>ระดับ (วิทยฐานะ)</b><span>เพิ่ม แก้ไข ลบ</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/position"><b>ตำแหน่ง</b><span>เพิ่ม แก้ไข ลบ</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/role"><b>บทบาทระบบ</b><span>admin / user</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/boardrole"><b>ตำแหน่งกรรมการ</b><span>เช่น ประธาน กรรมการ เลขานุการ</span></NuxtLink>
      <NuxtLink class="tile" to="/admin/report"><b>สรุปผลการประเมิน</b><span>คะแนนรายบุคคล พิมพ์รายงาน</span></NuxtLink>
    </div>
  </div>
</template>
