<script setup>
const api = useApi()
const rows = ref([])
const sections = ref([])
const empty = () => ({ indicator: '', section_id: '', detail: '', type: '', freq: '' })
const form = reactive(empty())
const editId = ref(null)
const msg = ref('')
const err = ref('')

async function load() {
  ;[rows.value, sections.value] = await Promise.all([api('/indicator'), api('/section')])
}
onMounted(load)

function reset() { editId.value = null; Object.assign(form, empty()) }

function edit(r) {
  editId.value = r.indicator_id
  Object.assign(form, {
    indicator: r.indicator, section_id: r.section_id,
    detail: r.detail ?? '', type: r.type ?? '', freq: r.freq ?? ''
  })
}

async function save() {
  msg.value = ''; err.value = ''
  try {
    const res = await api(editId.value ? `/indicator/${editId.value}` : '/indicator',
      { method: editId.value ? 'PUT' : 'POST', body: { ...form } })
    msg.value = res.message
    reset()
    await load()
  } catch (e) { err.value = errMsg(e) }
}

async function remove(r) {
  if (!confirm('ยืนยันการลบตัวชี้วัดนี้?')) return
  msg.value = ''; err.value = ''
  try {
    msg.value = (await api(`/indicator/${r.indicator_id}`, { method: 'DELETE' })).message
    await load()
  } catch (e) { err.value = errMsg(e) }
}
</script>

<template>
  <div>
    <h1>ตัวชี้วัด</h1>
    <div v-if="msg" class="msg ok">{{ msg }}</div>
    <div v-if="err" class="msg err">{{ err }}</div>
    <div v-if="!sections.length" class="msg info">
      ต้องสร้าง <NuxtLink to="/admin/section">หมวดการประเมิน</NuxtLink> ก่อน จึงจะเพิ่มตัวชี้วัดได้
    </div>

    <form class="card" @submit.prevent="save">
      <div class="row">
        <input v-model="form.indicator" placeholder="ชื่อตัวชี้วัด" required />
        <select v-model="form.section_id" required>
          <option value="" disabled>เลือกหมวด</option>
          <option v-for="s in sections" :key="s.section_id" :value="s.section_id">{{ s.section }}</option>
        </select>
      </div>
      <div class="row">
        <input v-model="form.type" placeholder="ประเภท (type)" />
        <input v-model="form.freq" placeholder="ความถี่ (freq)" />
      </div>
      <textarea v-model="form.detail" placeholder="รายละเอียด / เกณฑ์การให้คะแนน" />
      <div style="margin-top: 10px">
        <button class="green">{{ editId ? 'บันทึกการแก้ไข' : 'เพิ่มตัวชี้วัด' }}</button>
        <button v-if="editId" type="button" class="gray" style="margin-left: 8px" @click="reset">ยกเลิก</button>
      </div>
    </form>

    <div class="card table-wrap">
      <table>
        <thead><tr><th>#</th><th>ตัวชี้วัด</th><th>หมวด</th><th>ประเภท</th><th>ความถี่</th><th style="width: 140px"></th></tr></thead>
        <tbody>
          <tr v-for="r in rows" :key="r.indicator_id">
            <td>{{ r.indicator_id }}</td>
            <td>{{ r.indicator }}<div class="muted">{{ r.detail }}</div></td>
            <td>{{ r.section }}</td>
            <td>{{ r.type }}</td>
            <td>{{ r.freq }}</td>
            <td>
              <button class="small" @click="edit(r)">แก้ไข</button>
              <button class="small red" style="margin-left: 6px" @click="remove(r)">ลบ</button>
            </td>
          </tr>
          <tr v-if="!rows.length"><td colspan="6" class="muted">ยังไม่มีตัวชี้วัด</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
