<script setup>
const api = useApi()
const timeId = ref(null)
const rows = ref([])
const print = () => window.print()
const f2 = v => (v === null || v === undefined ? '-' : Number(v).toFixed(2))

watch(timeId, async (t) => {
  rows.value = t ? await api(`/report/summary?time_id=${t}`) : []
})
</script>

<template>
  <div>
    <h1>สรุปผลการประเมิน</h1>
    <RoundSelect v-model="timeId" class="no-print" />
    <div class="card table-wrap">
      <table>
        <thead>
          <tr><th>#</th><th>ชื่อ</th><th>แผนก</th><th>คะแนนประเมินตนเอง (รวม)</th><th>คะแนนกรรมการ (เฉลี่ยรวม)</th><th>จำนวนกรรมการที่ประเมิน</th></tr>
        </thead>
        <tbody>
          <tr v-for="(r, i) in rows" :key="r.id">
            <td>{{ i + 1 }}</td><td>{{ r.username }}</td><td>{{ r.department }}</td>
            <td>{{ f2(r.self_total) }}</td><td>{{ f2(r.board_avg) }}</td><td>{{ r.board_count ?? 0 }}</td>
          </tr>
          <tr v-if="!rows.length"><td colspan="6" class="muted">ไม่มีข้อมูล</td></tr>
        </tbody>
      </table>
    </div>
    <button class="no-print" @click="print">พิมพ์รายงาน</button>
  </div>
</template>
