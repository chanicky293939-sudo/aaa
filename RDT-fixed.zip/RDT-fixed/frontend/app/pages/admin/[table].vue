<script setup>
const route = useRoute()
const api = useApi()
const key = computed(() => String(route.params.table))
const cfg = computed(() => TABLES[key.value])

const rows = ref([])
const form = reactive({})
const editId = ref(null)
const msg = ref('')
const err = ref('')

const toInput = v => (v ? String(v).replace(' ', 'T').slice(0, 16) : '')
const show = (f, v) => (f.type === 'datetime-local' ? String(v ?? '').slice(0, 16) : v)

function reset() {
  editId.value = null
  Object.keys(form).forEach(k => delete form[k])
  cfg.value?.fields.forEach(f => (form[f.key] = ''))
}

async function load() {
  rows.value = await api(`/${key.value}`)
}

watch(key, () => { msg.value = ''; err.value = ''; reset(); if (cfg.value) load() }, { immediate: true })

function edit(row) {
  editId.value = row[cfg.value.pk]
  cfg.value.fields.forEach(f => {
    form[f.key] = f.type === 'datetime-local' ? toInput(row[f.key]) : row[f.key]
  })
}

async function save() {
  msg.value = ''; err.value = ''
  try {
    const path = editId.value ? `/${key.value}/${editId.value}` : `/${key.value}`
    const res = await api(path, { method: editId.value ? 'PUT' : 'POST', body: { ...form } })
    msg.value = res.message
    reset()
    await load()
  } catch (e) { err.value = errMsg(e) }
}

async function remove(row) {
  if (!confirm('ยืนยันการลบ?')) return
  msg.value = ''; err.value = ''
  try {
    const res = await api(`/${key.value}/${row[cfg.value.pk]}`, { method: 'DELETE' })
    msg.value = res.message
    await load()
  } catch (e) { err.value = errMsg(e) }
}
</script>

<template>
  <div v-if="cfg">
    <h1>{{ cfg.title }}</h1>
    <div v-if="msg" class="msg ok">{{ msg }}</div>
    <div v-if="err" class="msg err">{{ err }}</div>

    <form class="card" @submit.prevent="save">
      <div class="row">
        <label v-for="f in cfg.fields" :key="f.key" style="flex: 1; min-width: 180px">
          <div class="muted">{{ f.label }}</div>
          <input v-model="form[f.key]" :type="f.type || 'text'" :step="f.type === 'number' ? '0.01' : undefined"
                 :required="f.key !== 'weight'" style="width: 100%" />
        </label>
      </div>
      <button class="green">{{ editId ? 'บันทึกการแก้ไข' : 'เพิ่มข้อมูล' }}</button>
      <button v-if="editId" type="button" class="gray" style="margin-left: 8px" @click="reset">ยกเลิก</button>
    </form>

    <div class="card table-wrap">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th v-for="f in cfg.fields" :key="f.key">{{ f.label.split(' (')[0] }}</th>
            <th style="width: 140px"></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in rows" :key="r[cfg.pk]">
            <td>{{ r[cfg.pk] }}</td>
            <td v-for="f in cfg.fields" :key="f.key">{{ show(f, r[f.key]) }}</td>
            <td>
              <button class="small" @click="edit(r)">แก้ไข</button>
              <button class="small red" style="margin-left: 6px" @click="remove(r)">ลบ</button>
            </td>
          </tr>
          <tr v-if="!rows.length"><td :colspan="cfg.fields.length + 2" class="muted">ยังไม่มีข้อมูล</td></tr>
        </tbody>
      </table>
    </div>
  </div>
  <div v-else class="msg err">ไม่พบหน้านี้</div>
</template>
