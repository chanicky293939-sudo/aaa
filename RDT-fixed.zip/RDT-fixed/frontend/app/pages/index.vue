<script setup>
const api = useApi()
const user = useCookie('user')
const round = ref(null)
const summary = ref(null)
const progress = ref({ done: 0, total: 0 })
const isBoard = ref(false)
const loaded = ref(false)

onMounted(async () => {
  try {
    round.value = await api('/time/current')
    isBoard.value = (await api('/board/me')).isBoard
    if (round.value) {
      const [ind, mine, sum] = await Promise.all([
        api('/indicator'),
        api(`/userresult/me?time_id=${round.value.time_id}`),
        api(`/report/me?time_id=${round.value.time_id}`)
      ])
      progress.value = { done: mine.length, total: ind.length }
      summary.value = sum
    }
  } finally { loaded.value = true }
})

const f2 = v => (v === null || v === undefined ? '-' : Number(v).toFixed(2))
</script>

<template>
  <div>
    <h1>สวัสดี {{ user?.username }}</h1>

    <div v-if="loaded && !round" class="msg info">ขณะนี้ไม่มีรอบการประเมินที่เปิดอยู่</div>

    <div v-if="round" class="card">
      <b>รอบการประเมินปัจจุบัน</b>
      <div class="muted">{{ round.start.slice(0, 16) }} ถึง {{ round.expire.slice(0, 16) }}</div>
      <p>ประเมินตนเองแล้ว {{ progress.done }}/{{ progress.total }} ตัวชี้วัด</p>
      <p v-if="summary">
        คะแนนประเมินตนเอง (รวม): <b>{{ f2(summary.self_total) }}</b> ·
        คะแนนจากกรรมการ (เฉลี่ยรวม): <b>{{ f2(summary.board_avg) }}</b>
        <span class="muted">({{ summary.board_count ?? 0 }} ท่าน)</span>
      </p>
    </div>

    <div class="grid">
      <NuxtLink class="tile" to="/evaluate/self"><b>ประเมินตนเอง</b><span>กรอกคะแนนและแนบหลักฐาน</span></NuxtLink>
      <NuxtLink v-if="isBoard" class="tile" to="/evaluate/board"><b>ประเมินโดยกรรมการ</b><span>ให้คะแนนและความเห็นบุคลากร</span></NuxtLink>
      <NuxtLink v-if="user?.role === 'admin'" class="tile" to="/admin"><b>จัดการข้อมูลพื้นฐาน</b><span>ผู้ใช้ กรรมการ หมวด ตัวชี้วัด รอบเวลา</span></NuxtLink>
      <NuxtLink v-if="user?.role === 'admin'" class="tile" to="/admin/report"><b>สรุปผลการประเมิน</b><span>ดูคะแนนรายบุคคลและพิมพ์</span></NuxtLink>
    </div>
  </div>
</template>
