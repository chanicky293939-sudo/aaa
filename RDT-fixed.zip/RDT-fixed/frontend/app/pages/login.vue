<script setup>
definePageMeta({ layout: false })

const base = apiBase()
const form = reactive({ email: '', password: '' })
const error = ref('')
const loading = ref(false)
const token = useCookie('token', { maxAge: 60 * 60 * 24 })
const user = useCookie('user', { maxAge: 60 * 60 * 24 })

async function login() {
  error.value = ''
  loading.value = true
  try {
    const res = await $fetch(`${base}/api/auth/login`, { method: 'POST', body: form })
    token.value = res.token
    user.value = res.user
    await navigateTo('/')
  } catch (e) {
    error.value = errMsg(e, 'เข้าสู่ระบบไม่สำเร็จ')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="wrap">
    <form class="box" @submit.prevent="login">
      <h2>เข้าสู่ระบบ</h2>
      <p class="muted">ระบบประเมินบุคลากร วิทยาลัยเทคนิคพังงา</p>
      <input v-model="form.email" type="email" placeholder="อีเมล" required />
      <input v-model="form.password" type="password" placeholder="รหัสผ่าน" required />
      <p v-if="error" class="msg err">{{ error }}</p>
      <button :disabled="loading">{{ loading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ' }}</button>
      <NuxtLink to="/register">ยังไม่มีบัญชี? สมัครสมาชิก</NuxtLink>
    </form>
  </div>
</template>

<style scoped>
.wrap { min-height: 100vh; display: grid; place-items: center; }
.box { width: 340px; display: flex; flex-direction: column; gap: 12px; background: #fff; padding: 28px; border-radius: 12px; box-shadow: 0 4px 16px rgba(0,0,0,.08); }
h2 { margin: 0; }
</style>
