<script setup>
definePageMeta({ layout: false })

const base = apiBase()
const form = reactive({
  username: '', email: '', password: '', phone: '', czid: '',
  salary: '', department: '', level: '', position: ''
})
const departments = ref([])
const levels = ref([])
const positions = ref([])
const error = ref('')
const loading = ref(false)

onMounted(async () => {
  try {
    ;[departments.value, levels.value, positions.value] = await Promise.all([
      $fetch(`${base}/api/department`),
      $fetch(`${base}/api/level`),
      $fetch(`${base}/api/position`)
    ])
  } catch {
    error.value = 'โหลดรายการแผนก/ระดับ/ตำแหน่งไม่ได้ (backend รันอยู่หรือไม่?)'
  }
})

async function register() {
  error.value = ''
  loading.value = true
  try {
    await $fetch(`${base}/api/auth/register`, { method: 'POST', body: form })
    alert('สมัครสมาชิกสำเร็จ')
    await navigateTo('/login')
  } catch (e) {
    error.value = errMsg(e, 'สมัครสมาชิกไม่สำเร็จ')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="wrap">
    <form class="box" @submit.prevent="register">
      <h2>สมัครสมาชิก</h2>
      <input v-model="form.username" placeholder="ชื่อ-นามสกุล" required />
      <input v-model="form.email" type="email" placeholder="อีเมล" required />
      <input v-model="form.password" type="password" placeholder="รหัสผ่าน" required />
      <input v-model="form.phone" placeholder="เบอร์โทร" required />
      <input v-model="form.czid" maxlength="13" placeholder="เลขบัตรประชาชน 13 หลัก" required />
      <input v-model="form.salary" type="number" min="0" placeholder="เงินเดือน" />
      <select v-model="form.department" required>
        <option value="" disabled>เลือกแผนก</option>
        <option v-for="d in departments" :key="d.department_id" :value="d.department_id">{{ d.department }}</option>
      </select>
      <select v-model="form.level" required>
        <option value="" disabled>เลือกระดับ</option>
        <option v-for="l in levels" :key="l.level_id" :value="l.level_id">{{ l.level }}</option>
      </select>
      <select v-model="form.position" required>
        <option value="" disabled>เลือกตำแหน่ง</option>
        <option v-for="p in positions" :key="p.position_id" :value="p.position_id">{{ p.position }}</option>
      </select>
      <p v-if="error" class="msg err">{{ error }}</p>
      <button class="green" :disabled="loading">{{ loading ? 'กำลังบันทึก...' : 'สมัครสมาชิก' }}</button>
      <NuxtLink to="/login">มีบัญชีแล้ว? เข้าสู่ระบบ</NuxtLink>
    </form>
  </div>
</template>

<style scoped>
.wrap { min-height: 100vh; display: grid; place-items: center; padding: 24px 0; }
.box { width: 360px; display: flex; flex-direction: column; gap: 12px; background: #fff; padding: 28px; border-radius: 12px; box-shadow: 0 4px 16px rgba(0,0,0,.08); }
h2 { margin: 0; }
</style>
