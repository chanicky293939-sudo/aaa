<script setup>
const api = useApi()
const base = apiBase()

const timeId = ref(null)
const open = ref(false)
const indicators = ref([])
const maxScore = ref(5)
const rows = reactive({})        // indicator_id -> { score, file, newFile }
const msg = ref('')
const err = ref('')
const saving = ref(false)

onMounted(async () => {
  const [ind, cfg] = await Promise.all([api('/indicator'), api('/eval/config')])
  maxScore.value = cfg.maxScore
  indicators.value = ind
})

async function load() {
  if (!timeId.value || !indicators.value.length) return
  Object.keys(rows).forEach(k => delete rows[k])
  indicators.value.forEach(i => (rows[i.indicator_id] = { score: '', file: null, newFile: null }))
  const mine = await api(`/userresult/me?time_id=${timeId.value}`)
  mine.forEach(r => {
    if (rows[r.indicator_id]) {
      rows[r.indicator_id].score = r.score
      rows[r.indicator_id].file = r.file
    }
  })
}
watch([timeId, indicators], load)

const groups = computed(() => {
  const map = new Map()
  indicators.value.forEach(i => {
    if (!map.has(i.section_id)) map.set(i.section_id, { id: i.section_id, section: i.section, weight: i.weight, items: [] })
    map.get(i.section_id).items.push(i)
  })
  return [...map.values()]
})

const answered = computed(() => Object.values(rows).filter(r => r.score !== '' && r.score !== null).length)
const total = computed(() => Object.values(rows).reduce((s, r) => s + (Number(r.score) || 0), 0))

async function save() {
  msg.value = ''; err.value = ''
  const todo = indicators.value.filter(i => rows[i.indicator_id].score !== '' && rows[i.indicator_id].score !== null)
  if (!todo.length) { err.value = 'ยังไม่ได้กรอกคะแนน'; return }
  saving.value = true
  try {
    for (const i of todo) {
      const r = rows[i.indicator_id]
      const fd = new FormData()
      fd.append('indicator_id', i.indicator_id)
      fd.append('time_id', timeId.value)
      fd.append('score', r.score)
      if (r.newFile) fd.append('file', r.newFile)
      await api('/userresult', { method: 'POST', body: fd })
    }
    msg.value = `บันทึกสำเร็จ ${todo.length} ตัวชี้วัด`
    await load()
  } catch (e) {
    err.value = errMsg(e)
  } finally { saving.value = false }
}
</script>

<template>
  <div>
    <h1>ประเมินตนเอง</h1>
    <RoundSelect v-model="timeId" @open="v => (open = v)" />
    <div v-if="msg" class="msg ok">{{ msg }}</div>
    <div v-if="err" class="msg err">{{ err }}</div>
    <div v-if="!indicators.length" class="msg info">ผู้ดูแลระบบยังไม่ได้กำหนดตัวชี้วัด</div>

    <div v-if="indicators.length" class="card">
      <div class="muted">คะแนนต่อตัวชี้วัด 0 - {{ maxScore }} · กรอกแล้ว {{ answered }}/{{ indicators.length }} · คะแนนรวม {{ total.toFixed(2) }}</div>

      <div v-for="g in groups" :key="g.id">
        <div class="section-title"><span>{{ g.section }}</span><span class="muted">น้ำหนัก {{ g.weight }}</span></div>
        <div v-for="i in g.items" :key="i.indicator_id" class="ind">
          <div>
            <div class="name">{{ i.indicator }}</div>
            <div v-if="i.detail" class="detail">{{ i.detail }}</div>
            <div class="detail">
              <span v-if="i.type" class="badge">{{ i.type }}</span>
              <span v-if="i.freq" class="badge" style="margin-left: 6px">{{ i.freq }}</span>
            </div>
          </div>
          <div v-if="rows[i.indicator_id]" class="side">
            <div>
              <input v-model="rows[i.indicator_id].score" type="number" min="0" :max="maxScore" step="0.5"
                     :disabled="!open" placeholder="คะแนน" />
              <span class="muted"> / {{ maxScore }}</span>
            </div>
            <input type="file" :disabled="!open" style="max-width: 100%"
                   @change="rows[i.indicator_id].newFile = $event.target.files[0]" />
            <a v-if="rows[i.indicator_id].file" :href="base + rows[i.indicator_id].file" target="_blank">ดูไฟล์ที่แนบไว้</a>
          </div>
        </div>
      </div>

      <div style="margin-top: 14px">
        <button class="green" :disabled="!open || saving" @click="save">{{ saving ? 'กำลังบันทึก...' : 'บันทึกคะแนน' }}</button>
        <span v-if="!open && timeId" class="muted" style="margin-left: 10px">อยู่นอกช่วงเวลาประเมิน แก้ไขไม่ได้</span>
      </div>
    </div>
  </div>
</template>
