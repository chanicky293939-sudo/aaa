<script setup>
const api = useApi()
const base = apiBase()

const board = ref(null)           // { isBoard, role }
const timeId = ref(null)
const open = ref(false)
const targets = ref([])
const target = ref('')
const indicators = ref([])
const maxScore = ref(5)
const rows = reactive({})         // indicator_id -> { score, comment, selfScore, selfFile }
const signatureFile = ref(null)
const signatureSaved = ref(null)
const msg = ref('')
const err = ref('')
const saving = ref(false)

onMounted(async () => {
  board.value = await api('/board/me')
  if (!board.value.isBoard) return
  const [t, ind, cfg] = await Promise.all([api('/board/targets'), api('/indicator'), api('/eval/config')])
  targets.value = t
  indicators.value = ind
  maxScore.value = cfg.maxScore
})

async function load() {
  Object.keys(rows).forEach(k => delete rows[k])
  signatureSaved.value = null
  signatureFile.value = null
  if (!timeId.value || !target.value || !indicators.value.length) return
  indicators.value.forEach(i => (rows[i.indicator_id] = { score: '', comment: '', selfScore: null, selfFile: null }))
  const res = await api(`/board/evaluation?target=${target.value}&time_id=${timeId.value}`)
  res.self.forEach(r => { if (rows[r.indicator_id]) { rows[r.indicator_id].selfScore = r.score; rows[r.indicator_id].selfFile = r.file } })
  res.board.forEach(r => { if (rows[r.indicator_id]) rows[r.indicator_id].score = r.score })
  res.attachments.forEach(r => {
    if (rows[r.indicator_id]) rows[r.indicator_id].comment = r.comment ?? ''
    if (r.signature) signatureSaved.value = r.signature
  })
}
watch([timeId, target, indicators], load)

const groups = computed(() => {
  const map = new Map()
  indicators.value.forEach(i => {
    if (!map.has(i.section_id)) map.set(i.section_id, { id: i.section_id, section: i.section, items: [] })
    map.get(i.section_id).items.push(i)
  })
  return [...map.values()]
})
const total = computed(() => Object.values(rows).reduce((s, r) => s + (Number(r.score) || 0), 0))

async function save() {
  msg.value = ''; err.value = ''
  const items = indicators.value
    .filter(i => rows[i.indicator_id].score !== '' && rows[i.indicator_id].score !== null)
    .map(i => ({ indicator_id: i.indicator_id, score: rows[i.indicator_id].score, comment: rows[i.indicator_id].comment }))
  if (!items.length) { err.value = 'ยังไม่ได้กรอกคะแนน'; return }

  const fd = new FormData()
  fd.append('target', target.value)
  fd.append('time_id', timeId.value)
  fd.append('items', JSON.stringify(items))
  if (signatureFile.value) fd.append('signature', signatureFile.value)

  saving.value = true
  try {
    msg.value = (await api('/board/evaluation', { method: 'POST', body: fd })).message
    await load()
  } catch (e) { err.value = errMsg(e) } finally { saving.value = false }
}
</script>

<template>
  <div>
    <h1>ประเมินโดยคณะกรรมการ</h1>
    <div v-if="board && !board.isBoard" class="msg info">คุณไม่ได้เป็นกรรมการประเมิน (ให้ผู้ดูแลระบบแต่งตั้งที่เมนู “กรรมการ”)</div>

    <template v-if="board?.isBoard">
      <p class="muted">ตำแหน่งของคุณ: <span class="badge">{{ board.role }}</span></p>
      <RoundSelect v-model="timeId" @open="v => (open = v)" />
      <div class="row">
        <label>ผู้รับการประเมิน</label>
        <select v-model="target" style="max-width: 420px">
          <option value="" disabled>เลือกบุคลากร</option>
          <option v-for="t in targets" :key="t.id" :value="t.id">{{ t.username }} · {{ t.department }} · {{ t.position }}</option>
        </select>
      </div>

      <div v-if="msg" class="msg ok">{{ msg }}</div>
      <div v-if="err" class="msg err">{{ err }}</div>

      <div v-if="target && indicators.length" class="card">
        <div class="muted">คะแนนต่อตัวชี้วัด 0 - {{ maxScore }} · คะแนนรวมที่ให้ {{ total.toFixed(2) }}</div>

        <div v-for="g in groups" :key="g.id">
          <div class="section-title"><span>{{ g.section }}</span></div>
          <div v-for="i in g.items" :key="i.indicator_id" class="ind">
            <div>
              <div class="name">{{ i.indicator }}</div>
              <div v-if="i.detail" class="detail">{{ i.detail }}</div>
              <div v-if="rows[i.indicator_id]" class="detail">
                ประเมินตนเอง: <b>{{ rows[i.indicator_id].selfScore ?? '-' }}</b>
                <a v-if="rows[i.indicator_id].selfFile" :href="base + rows[i.indicator_id].selfFile" target="_blank" style="margin-left: 8px">ไฟล์แนบ</a>
              </div>
            </div>
            <div v-if="rows[i.indicator_id]" class="side">
              <div>
                <input v-model="rows[i.indicator_id].score" type="number" min="0" :max="maxScore" step="0.5"
                       :disabled="!open" placeholder="คะแนน" />
                <span class="muted"> / {{ maxScore }}</span>
              </div>
              <textarea v-model="rows[i.indicator_id].comment" :disabled="!open" placeholder="ความคิดเห็น" />
            </div>
          </div>
        </div>

        <div class="row" style="margin-top: 14px">
          <label>ลายเซ็น (รูปภาพ)</label>
          <input type="file" accept="image/*" :disabled="!open" @change="signatureFile = $event.target.files[0]" />
          <a v-if="signatureSaved" :href="base + signatureSaved" target="_blank">ดูลายเซ็นที่บันทึกไว้</a>
        </div>
        <button class="green" :disabled="!open || saving" @click="save">{{ saving ? 'กำลังบันทึก...' : 'บันทึกผลการประเมิน' }}</button>
        <span v-if="!open && timeId" class="muted" style="margin-left: 10px">อยู่นอกช่วงเวลาประเมิน แก้ไขไม่ได้</span>
      </div>
    </template>
  </div>
</template>
