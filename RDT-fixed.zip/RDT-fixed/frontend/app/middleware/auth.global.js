// หน้าที่เปิดได้โดยไม่ login: /login และ /register ส่วน /admin/* เฉพาะ admin
export default defineNuxtRouteMiddleware((to) => {
  const token = useCookie('token')
  const user = useCookie('user')
  const open = ['/login', '/register']

  if (!token.value && !open.includes(to.path)) return navigateTo('/login')
  if (token.value && open.includes(to.path)) return navigateTo('/')
  if (to.path.startsWith('/admin') && user.value?.role !== 'admin') return navigateTo('/')
})
