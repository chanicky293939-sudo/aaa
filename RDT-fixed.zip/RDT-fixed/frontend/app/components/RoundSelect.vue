<script setup>
// เลือกรอบประเมิน: ค่าเริ่มต้น = รอบที่เปิดอยู่ ถ้าไม่มีใช้รอบล่าสุด
const model = defineModel()
const emit = defineEmits(['open'])
const api = useApi()
const rounds = ref([])
const current = ref(null)
const loaded = ref(false)

onMounted(async () => {
  try {
    rounds.value = await api('/time')
    current.value = await api('/time/current')
    model.value = current.value?.time_id ?? rounds.value[0]?.time_id ?? null
  } finally { loaded.value = true }
})

const isOpen = computed(() => !!current.value && model.value === current.value.time_id)
watch(isOpen, v => emit('open', v), { immediate: true })
</script>

<template>
  <div class="row">
    <label>รอบการประเมิน</label>
    <select v-model="model" style="max-width: 360px">
      <option v-for="r in rounds" :key="r.time_id" :value="r.time_id">
        {{ r.start.slice(0, 16) }} ถึง {{ r.expire.slice(0, 16) }}
        {{ current && r.time_id === current.time_id ? '(เปิดอยู่)' : '' }}
      </option>
    </select>
    <span v-if="loaded && !rounds.length" class="muted">ยังไม่มีรอบการประเมิน</span>
    <span v-else-if="model && !isOpen" class="badge">ปิดแล้ว ดูได้อย่างเดียว</span>
  </div>
</template>
