// เรียก API ของ backend พร้อมแนบ token; ถ้า token หมดอายุ (401) พากลับหน้า login
export const useApi = () => {
  const base = useRuntimeConfig().public.apiBase
  const token = useCookie('token')
  const user = useCookie('user')

  return (path, opts = {}) =>
    $fetch(`${base}/api${path}`, {
      ...opts,
      headers: {
        ...(opts.headers || {}),
        ...(token.value ? { Authorization: `Bearer ${token.value}` } : {})
      },
      onResponseError({ response }) {
        if (response.status === 401 && token.value) {
          token.value = null
          user.value = null
          navigateTo('/login')
        }
      }
    })
}

export const apiBase = () => useRuntimeConfig().public.apiBase

// ข้อความ error จาก backend
export const errMsg = (e, fallback = 'เกิดข้อผิดพลาด') => e?.data?.message || fallback
