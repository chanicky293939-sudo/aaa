// ตารางอ้างอิงที่ใช้หน้าจัดการแบบเดียวกัน (admin/[table].vue)
export const TABLES = {
  department: { title: 'แผนก', pk: 'department_id',
    fields: [{ key: 'department', label: 'ชื่อแผนก' }] },
  level: { title: 'ระดับ (วิทยฐานะ)', pk: 'level_id',
    fields: [{ key: 'level', label: 'ชื่อระดับ' }] },
  position: { title: 'ตำแหน่ง', pk: 'position_id',
    fields: [{ key: 'position', label: 'ชื่อตำแหน่ง' }] },
  role: { title: 'บทบาทระบบ', pk: 'role_id',
    fields: [{ key: 'role', label: 'ชื่อบทบาท (admin = ผู้ดูแลระบบ, user = ผู้ใช้ทั่วไป)' }] },
  boardrole: { title: 'ตำแหน่งกรรมการ', pk: 'role_id',
    fields: [{ key: 'role', label: 'ชื่อตำแหน่งกรรมการ' }] },
  section: { title: 'หมวดการประเมิน', pk: 'section_id',
    fields: [{ key: 'section', label: 'ชื่อหมวด' },
             { key: 'weight', label: 'น้ำหนัก', type: 'number' }] },
  time: { title: 'รอบเวลาประเมิน', pk: 'time_id',
    fields: [{ key: 'start', label: 'เริ่ม', type: 'datetime-local' },
             { key: 'expire', label: 'สิ้นสุด', type: 'datetime-local' }] }
}
