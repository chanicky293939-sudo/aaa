<script setup>
const user = useCookie('user')
const token = useCookie('token')
const api = useApi()
const isBoard = ref(false)

onMounted(async () => {
  try { isBoard.value = (await api('/board/me')).isBoard } catch {}
})

function logout() {
  token.value = null
  user.value = null
  navigateTo('/login')
}
</script>

<template>
  <div>
    <nav class="nav">
      <span class="brand">ระบบประเมินบุคลากร</span>
      <NuxtLink to="/">หน้าแรก</NuxtLink>
      <NuxtLink to="/evaluate/self">ประเมินตนเอง</NuxtLink>
      <NuxtLink v-if="isBoard" to="/evaluate/board">ประเมินโดยกรรมการ</NuxtLink>
      <template v-if="user?.role === 'admin'">
        <NuxtLink to="/admin" exact-active-class="router-link-active" active-class="">ข้อมูลพื้นฐาน</NuxtLink>
        <NuxtLink to="/admin/users">ผู้ใช้</NuxtLink>
        <NuxtLink to="/admin/board">กรรมการ</NuxtLink>
        <NuxtLink to="/admin/section">หมวด</NuxtLink>
        <NuxtLink to="/admin/indicator">ตัวชี้วัด</NuxtLink>
        <NuxtLink to="/admin/time">รอบเวลา</NuxtLink>
        <NuxtLink to="/admin/report">สรุปผล</NuxtLink>
      </template>
      <span class="grow" />
      <span class="who">{{ user?.username }}</span>
      <button class="small gray" @click="logout">ออกจากระบบ</button>
    </nav>
    <main class="container">
      <slot />
    </main>
  </div>
</template>
